#include <stdio.h>			
#include <ctype.h>
#include <cstring>
#include <string>
#include <sys/wait.h>
#include <iostream>
#include <pthread.h>
#include <string>
#include <fstream> 
#include <semaphore.h> 
#include <unistd.h> 
using namespace std;

 int Total_Customers,Total_Cooks,Total_Waiters;
 int Customer_ID;
 string Customer_Name;
 string Dish_Array[11];
 int cook_Counter=0; 
 int Delivery_Amount=100;
 int Price_Array[10];
 int Waiting_Array[10];
 pthread_t thread_id1;
 int total_sum=0;
 static int Today_Sale=0;
 int C_ID=0;
 
 int Waitr_ID=0;
 int Array_Customer[5];
 
 void ReadFile(string Filename, string Person_Name)
 {
   
           fstream file;
           string str,Fil_Nam;
           int counter=1;
           int digit; 
           int Sum_Total=0;
           Fil_Nam= Filename;
  
            
            file.open(Fil_Nam.c_str());
  
           cout<<endl<<endl<<endl;   
           getline(file, str); 
           while (file >> digit)
                 {
                   
                   
                   if(counter%2!=0)
                     {
                       cout<<Person_Name<<" ID -> "<<digit<<endl<<endl;
                      }
                      
                      if(counter%2==0)
                     {
                       cout<<Person_Name<<" Total Amount calculation -> "<<digit<<endl<<endl;
                       Sum_Total=Sum_Total+digit;
                       
                      }
                      
                      ++counter;
                      
                  }
           
           cout<<endl<<endl<<endl;       
           cout<<"Today has total "<<Person_Name<<" Bill is -> "<<Sum_Total<<endl;    
           cout<<endl<<endl<<endl;   
           file.close();
  
 }
 
 
 
void Customer_recieve(string str3,string out_str)
     {
       cout<<endl<<endl<<endl;
       cout<<"My Customer ID -> "<<out_str<<" And I Received my Order! "<<endl;
       cout<<"Thank You for serving !"<<endl;
       cout<<endl<<endl<<endl;
      
     }
 
 
 void cook(string* pti,int size,int customer_ID)    //in coock function
       {
          
         int fd3[2];
         int fd4[2];
	
         pipe(fd3);//p=>C
         pipe(fd4);//C=>P
      
           cout<<endl<<endl<<endl;
           for(int i=0;i<size;i++)     
             {
         
             cout<<" "<<"Dish -> "<<1+i<<" ->"<<pti[i]<<endl;  
              
             }
         
             cout<<endl<<endl<<endl;
             int not_accept=0;
             cout<<"This is Cook Thread->"<<endl;
             cout<<"We prepared the Order For Customer ID-> "<<customer_ID<<endl<<endl;
             int c_count=Total_Cooks;
             
            for(int i=0;i<Total_Cooks && cook_Counter<Total_Cooks ;i++)     
               {   
                    
                if(pti[i]!="\0") //&& size<=Total_Cooks)
                   {
                    cout<<"  The Cook ID -> "<<1+cook_Counter<<"  Prepare Dish -> "<<pti[i]<<endl<<endl;  
                    sleep(2);
                    cook_Counter++;
                    c_count--;
                    
                   }
                   
                    if(size> Total_Cooks && c_count==0)
                       {
                        not_accept=i;
                        cout<<"Sorry! There is no available coook! to Prepare Dish -> "<<pti[i+1]<<endl<<endl;
                        cout<<"please wait! "<<endl<<endl;
                       }
                       
               } 
               
               
              
              sleep(2);
              
              if(not_accept!=0)
              {
               cout<<"Now the remaining order prepared because some of cooks are free!"<<endl<<endl;
               cout<<"  The Cook ID -> "<<1+c_count<<"  Prepare Dish -> "<<pti[not_accept+1]<<endl<<endl;  
               
              }
              
             // cout<<"The Cusmtomer ID-> "<<customer_ID<<" Has prepared Order "<<endl<<endl;
             //write prepared order in prepared.txt
             {
              
              
                 ofstream file_OutPut2;                             // Create Object of Ofstream
                 ifstream file_Input2;
                 file_Input2.open("PreparedOrder.txt");
                 file_OutPut2.open ("PreparedOrder.txt",ios::app);    // Append mode
                 
                 
                 if(file_Input2.is_open())
                   {
                    
                    file_OutPut2<<C_ID<<" ";
                    
                    for(int j=0; j<size; j++)    // j<strlen(Dish_Array);
                    {
                      if(pti[j] !="\0")       // Waiting_Array[i]=5; 
                          {
                            file_OutPut2<<pti[j]<<" "; 
                          }
                    } 
                    
                   } 
                   
                    file_OutPut2<<"\n"; 
                    file_Input2.close();
                    file_OutPut2.close(); // Closing the file
                    
              
              
              
             
             }
         
         
          }
          
          
  
  void* Manager_Waiter(void* ptr2)
  {
   int *T_Waiter= (int *)ptr2;      
   Waitr_ID++;
   cout<<"The waiter ID-> "<<Waitr_ID<<" Has turn and Pick Prepared Food!"<<endl;
   cout<<"And Go to Deliver Order!"<<endl<<endl;
   
   
           fstream file3;
           string str3,Fil_Nam3;
           int counter=1;
           string out_str; 
          
           Fil_Nam3= "PreparedOrder.txt";
  
            
            file3.open(Fil_Nam3.c_str());
            for(int i=1; i<=Total_Waiters;i++)
               {
                if(Waitr_ID==i)
                  {
                   file3>> out_str;
                   getline(file3, str3);
                   cout<<"The Order Deliver to  Customer ID -> "<<out_str<<endl;
                   cout<<"The Order List Contains following Items-> "<<str3<<endl<<endl;
                   cout<<endl<<endl<<endl;
                   //now call customer to sent message is he recieve order
                   Customer_recieve(str3,out_str);	 
            
                  }
                  
                  else
                       {
                         getline(file3, str3);
                       }
                
               }
            
            
                 
            file3.close(); 
             
             //Writting Daily Waiter sale
             
            {
             
                 ofstream file_OutPut7;                             // Create Object of Ofstream
                 ifstream file_Input7;
                 file_Input7.open("DailyWaiterSale.txt");
                 file_OutPut7.open("DailyWaiterSale.txt",ios::app);    // Append mode
                 
                 
                 if(file_Input7.is_open())
                   {
                    
                    file_OutPut7<<Waitr_ID<<" "<<Delivery_Amount<<"\n";;                   
                    
                   } 
                   
                    file_Input7.close();
                    file_OutPut7.close(); // Closing the file
                    
            
              
            }
            
            
   
            pthread_exit(NULL);
   
   
   }
  
    void* Manager_Cook(void* ptr1) 
                    {
      
                       /*  char* T_Cook= (char *)ptr1;
      
      
                        for(int i=0;i<strlen(T_Cook);i++)
      
                           {
          
                             cout<<"Dish -> "<<i<<" ->"<<T_Cook[i];  
              
                            }  
         
                             int fd3[2];
                             int fd4[2];
	
                              pipe(fd3);//p=>C
                              pipe(fd4);//C=>P
    
                              if(Total_Cooks>=9)
                                {
       
       
                                 }
                              
                               */
    
    
    
                                pthread_exit(NULL);
  
                          }
 

 
 
           void* Manager_Customer(void* ptr1) 
                 {
                   int counter_dish=0;
                    ofstream File_Out;                         // Create Object of Ofstream
                    ifstream File_In;
                     File_In.open("Dailyasale.txt");
                     File_Out.open ("Dailyasale.txt",ios::app); // Append mode
     
                     int *T_Customer=(int *)ptr1;
  
  
                      int fd[2];
                      int fd1[2];
	
                      pipe(fd);//p=>C
                      pipe(fd1);//C=>P
  
                       // cout<<"Enter Customer ID! -> ";
                       // cin>>Customer_ID;	
 
                       C_ID++; 
                       cout<<"The Customer ID is! -> "<<C_ID<<endl;
   
                       cout<<"Enter Customer Name! -> ";
                       cin>>Customer_Name;
   
                       pid_t pid=fork();
   
                       int counter=0; 
                       if(pid>0)
                         { 
    
                           for(; counter<10; counter++)
	 	              {
		
			          //char buff[100];
			           char buff1[100];
			
			          //cout<<"This is Manager! "<<endl;
			
			          //cin>>buff;   
			           char buff[]= {'I','m',' ','D','i','s','p','l','a','y',' ','y','o','u',' ','t','h','e',' ','m','e','n','u','\0'};
			
			           write(fd[1],buff,strlen(buff)+1);
			           //read pipe 2
			           if(buff[0]=='0')
			              break;
			
			             read(fd1[0],buff1,sizeof(buff1));
			             cout<<"message received:Parent "<<buff1<<endl;
		       
		                     if(buff1[0]=='0')
		                       {
			                 break;
			                }
			  
		       		//end of for loop        		        	  			   
                                   }  
		
			             wait(NULL);	
		                     close(fd[0]);
		                     close(fd1[1]); 

                            }
   
   
                             else if(pid==0)
	                            {
		                      close(fd[1]);
		                      close(fd1[0]);
		                      for(; counter<10; counter++)
		                         {
			                   char buff1[100];
			                   char buff[100];
		
			                    read(fd[0],buff1,sizeof(buff1));
		
			                     cout<<"message received:Child "<<buff1<<endl;
			                     cout<<"Customer-> Enter 1 for Request More Dishes : Parent: "<<endl;
			                     cout<<"Customer-> Enter 0 To finalize Order: Parent: "<<endl;
			
			                    if(buff1[0]=='0')
			                      { 
			                        break;
		                              }
		        		        		        		        		        		        
		        
			                       //write pipe 2 Customer
			
		                               cout<<"Please enter Your Choice :child -> "<<endl;
		                               cin>>buff;	
		
				
		
		      if(buff[0]=='1')
			{ 
			  
			  
			  int input=1;
                         for(int i=0; i<10 && input!=0; i++) 
     {
      
      cout<<" ________________________________________________________________________"<<endl;
      cout<<"|                                                                        |"<<endl;
      cout<<"|               Welcome to Hawana Fast Food Restaurant                   |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|                                                                        |"<<endl;
      cout<<"|                              Menu                                      |"<<endl;
      cout<<"|========================================================================|"<<endl;
      cout<<"|                                                                        |"<<endl;
      cout<<"|             Enter -> 1: To Purchase Zinger Burger                      |"<<endl;
      cout<<"|             Price is -> : 350                                          |"<<endl;
      cout<<"|             Preparation time is -> : 2 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 2: To Purchase Chicken Burger                     |"<<endl;
      cout<<"|             Price is -> : 300                                          |"<<endl;
      cout<<"|             Preparation time is -> : 2  minutes                        |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 3: To Purchase Krunch Burger                      |"<<endl;
      cout<<"|             Price is -> : 250                                          |"<<endl;
      cout<<"|             Preparation time is -> : 2  minutes                        |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 4: To Purchase  Kentucky Burger                   |"<<endl;
      cout<<"|             Price is -> : 400                                          |"<<endl;
      cout<<"|             Preparation time is -> : 2 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;     
      cout<<"|             Enter -> 5: To Purchase Dancing Fajita Pizza               |"<<endl;
      cout<<"|             Price is -> : 450                                          |"<<endl;
      cout<<"|             Preparation time is -> : 2 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 6: To Purchase Tarzan Tikka Pizza                 |"<<endl;
      cout<<"|             Price is -> : 500                                          |"<<endl;
      cout<<"|             Preparation time is -> : 3 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 7: To Purchase Arabic Ranch Pizza                 |"<<endl;
      cout<<"|             Price is -> : 550                                          |"<<endl;
      cout<<"|             Preparation time is -> : 3 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;     
      cout<<"|             Enter -> 8: To Purchase Chicken Piece                      |"<<endl;
      cout<<"|             Price is -> : 200                                          |"<<endl;
      cout<<"|             Preparation time is -> : 3  minutes                        |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 9: To Purchase Cold Drink                         |"<<endl;
      cout<<"|             Price is -> : 100                                          |"<<endl;
      cout<<"|             Preparation time is -> : 3 minutes                         |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 10: To Purchase Fries                             |"<<endl;
      cout<<"|             Price is -> : 150                                          |"<<endl;
      cout<<"|             Preparation time is -> : 3  minutes                        |"<<endl; 
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|             Enter -> 0: To Final Menu and no other item added          |"<<endl;
      cout<<"|------------------------------------------------------------------------|"<<endl;
      cout<<"|-------------Enter your choice here ------------------------------------>";
      
      cin>>input;
      
      if(input!=0)
      {
        switch(input)
              {
                case 1:
                       {
                                                                
                         Dish_Array[i] ="Zinger_Burger"; 
                         Waiting_Array[i]=2;
                         Price_Array[i]=350;
                         
                         total_sum=total_sum+Price_Array[i];
                         
                       } 
                                              
                       break;
                
                case 2:
                       {
                         Dish_Array[i]="Chicken_Burger";
                         Waiting_Array[i]=2;
                         Price_Array[i]=300;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                
                case 3:
                       {
                         Dish_Array[i]="Krunch_Burger";
                          Waiting_Array[i]=2;
                         Price_Array[i]=250;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;        
                       
               case 4:
                       {
                         Dish_Array[i]="Kentucky_Burger";
                         Waiting_Array[i]=2;
                         Price_Array[i]=400;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
               case 5:
                       {
                         Dish_Array[i]="Dancing_Fajita";
                         Waiting_Array[i]=2;
                         Price_Array[i]=450;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
               case 6:
                       {
                         Dish_Array[i]="Tarzan_Tikka";
                         Waiting_Array[i]=3;
                         Price_Array[i]=500;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
              case 7:
                       {
                         Dish_Array[i]="Arabic_Ranch";
                         Waiting_Array[i]=3;
                         Price_Array[i]=550;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
             case 8:
                       {
                         Dish_Array[i]="Chicken_Piece";
                         Waiting_Array[i]=3;
                         Price_Array[i]=200;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
             
             case 9:
                       {
                         Dish_Array[i]="Cold_Drink";
                         Waiting_Array[i]=3;
                         Price_Array[i]=100;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
            
            case 10:
                       {
                         Dish_Array[i]="Fries";
                         Waiting_Array[i]=3; 
                         Price_Array[i]=150;
                         total_sum=total_sum+Price_Array[i];
                       } 
                       
                       break;
                       
            default:
                     cout<<"Error! Please Enter correct Choice";                                                                       
                               
         
             }   //switch ended
             
             
     }  //if ended        
  
  
  
  
  
  }
    //for ended  
                {
                
                 
                 
                 ofstream file_OutPut;                             // Create Object of Ofstream
                 ifstream file_Input;
                 file_Input.open("DishesCustomer.txt");
                 file_OutPut.open ("DishesCustomer.txt",ios::app);    // Append mode
                 
                 
                 if(file_Input.is_open())
                   {
                    
                    file_OutPut<<"\n"<<C_ID<<" ";
                    
                    for(int j=0; j<10; j++)    // j<strlen(Dish_Array);
                    {
                      if(Dish_Array[j] !="\0")       // Waiting_Array[i]=5; 
                          {
                            file_OutPut<<Waiting_Array[j]<<" "<<Dish_Array[j]<<" "; 
                          }
                    } 
                    
                   } 
                   
                    file_Input.close();
                    file_OutPut.close(); // Closing the file
                    
                    
                 
                }
                
                
                 for(int j=0; j<10; j++)
                    {
                      if(Dish_Array[j] !="\0")
                          {
                            ++counter_dish;
                            cout<<"Your Dish number-> "<<1+j<< " is -> "<<Dish_Array[j]<<endl; 
                          }
                    } 
          
                 
                 
                 if(File_In.is_open())
                   {
                    
                    File_Out<<C_ID<<" "<<total_sum<<"\n";
                    
                   } 
                   
                    File_In.close();
                    File_Out.close(); // Closing the file
                 
                 Array_Customer[C_ID]=total_sum; 
                 
                 
                    
                 Today_Sale=Today_Sale+total_sum;
                 cout<<"The Customer Name-> "<<Customer_Name<<" & Customer ID is-> "<<C_ID<<" has total Bill-> "<<total_sum<<endl<<endl;
                // Manager_Cook(Dish_Array);	
                 cook(Dish_Array,counter_dish,C_ID);	  	     
	}
		
						
		write(fd1[1],buff,strlen(buff)+1);
		   
		   if(buff[0]=='0')
			break;
		     }
				
	}
	

    
       pthread_exit(NULL);
    
  
  }     
  
  
 
 int main()
  {
 
   cout<<"                Welcome to Hawana Fast Food Restaurant          "<<endl;
   cout<<"               =======================================          "<<endl<<endl;
   
   cout<<"For Exact Number of Customer, Waiter and cook!  "<<endl;
   cout<<"Please Enter the Correct Information! "<<endl<<endl;
    
   cout<<"Enter Total number of Customer! -> ";
   cin>>Total_Customers;
   
   cout<<"Enter Total number of Cooks! -> ";
   cin>>Total_Cooks;
   
   cout<<"Enter Total number of Waiter! -> ";
   cin>>Total_Waiters;
   
   bool flagstatus=false;
   bool CookStatus=false;
    pthread_t threads_id[Total_Customers];
    
    pthread_t WaiterThreads[Total_Waiters]; 
    
    for(int z= 0; z < Total_Customers; z++) 
           {

            pthread_create(&threads_id[z], NULL, Manager_Customer, (void*)&Total_Customers);
            pthread_join(threads_id[z], NULL);
 
            if( z==(Total_Customers-1) )
               {
                flagstatus=true;
               }
 
           }
    
    
    
           
     if(flagstatus==true)
       {
        
        for(int z= 0; z < Total_Waiters; z++) 
           {

            pthread_create(&WaiterThreads[z], NULL, Manager_Waiter, (void*)&Total_Waiters);
            pthread_join(WaiterThreads[z], NULL);
 
            if( z==(Total_Waiters-1) )
               {
                CookStatus=true;
               }
 
           }
       }      
          
         
          string File_Name= "Dailyasale.txt";
          string str_id="Customer";
          ReadFile(File_Name,str_id);
          
          string File_Name2= "DailyWaiterSale.txt";  
          string str_id2="Waiter";
          ReadFile(File_Name2,str_id2);
          
           pthread_exit(NULL);

           return 0;
           
   
}



